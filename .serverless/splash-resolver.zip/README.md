# splash-resolver
This project, provides an AWS based service to easily discover in which database a splash exists
